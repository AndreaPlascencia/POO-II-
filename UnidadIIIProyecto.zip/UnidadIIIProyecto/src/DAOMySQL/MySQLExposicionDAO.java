/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IExposicionDAO;
import Modelo.Exposicion;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLExposicionDAO implements IExposicionDAO {
    //Propiedades para controlar la base de datos
    private Connection conn = null;
    private ResultSet rs = null;
    private PreparedStatement ps = null;
    
    //Consultas SQL
    private final String INSERT = "INSERT INTO exposicion (idGaleria, tituloExposicion, fechaInicio, fechaFinal)"
            + " VALUES (?, ?, ?, ?)";
    
    private final String UPDATE = "UPDATE exposicion SET idGaleria = ?,"
            + " tituloExposicion = ?, fechaInicio = ?, fechaFinal = ? WHERE idExposicion = ?";
    
    private final String DELETE = "DELETE FROM exposicion WHERE idExposicion = ?";
    
    private final String GETONE = "SELECT idExposicion, idGaleria,"
            + " tituloExposicion, fechaInicio, fechaFinal FROM exposicion"
            + " WHERE idExposicion = ?";
    
    private final String GETONEBYTITLE = "SELECT idExposicion, idGaleria,"
            + " tituloExposicion, fechaInicio, fechaFinal FROM exposicion"
            + " WHERE tituloExposicion = ?";
    
    private final String GETALLEXPOSITIONSBYGALLERY = "SELECT idExposicion,"
            + " idGaleria, tituloExposicion, fechaInicio, fechaFinal"
            + " FROM exposicion WHERE idGaleria = ?";
    
    /**
     * Método para insertar una exposición
     * @param exposicion
     * @throws DAOException 
     */
    @Override
    public void insertar(Exposicion exposicion) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros
            ps = conn.prepareStatement(INSERT,
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, exposicion.getIdGaleria());
            ps.setString(2, exposicion.getTituloExposicion());
            java.sql.Date sqlFechaInicio = convertir(exposicion.getFechaInicio());
            ps.setDate(3, sqlFechaInicio);
            java.sql.Date sqlFechaFinal = convertir(exposicion.getFechaFinal());
            ps.setDate(4, sqlFechaFinal);
            
            //Ejecutamos la cosulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("No se pudo guardar la nueva exposición");
            }else {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    exposicion.setIdExposicion(rs.getInt(1));
                }else {
                    throw new DAOException("No se pudo asignar el ID a esta "
                            + "exposicion");
                }
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método insertar
    
    /**
     * Método para modificar una exposición
     * @param exposicion
     * @throws DAOException 
     */
    @Override
    public void modificar(Exposicion exposicion) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros de entrada
            ps = conn.prepareStatement(UPDATE);
            ps.setInt(1, exposicion.getIdGaleria());
            ps.setString(2, exposicion.getTituloExposicion());
            java.sql.Date sqlFechaInicio = convertir(exposicion.getFechaInicio());
            ps.setDate(3, sqlFechaInicio);
            java.sql.Date sqlFechaFinal = convertir(exposicion.getFechaFinal());
            ps.setDate(4, sqlFechaFinal);
            ps.setInt(5, exposicion.getIdExposicion());
            
            //Ejecutamos la consulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema "
                        + "y no se guardaron los cambios");
            }
        }catch (SQLException ex) {
            throw new DAOException("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método modificar
    
    /**
     * Método para eliminar una exposición por su ID
     * @param idExposicion
     * @throws DAOException 
     */
    @Override
    public void eliminar(Integer idExposicion) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando parametros de entrada
            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, idExposicion);
            
            //Ejecutamos la consulta y verificamos el resultado 
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no "
                        + "se pudo eliminar el registro");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método eliminar
    
    /**
     * Método que obtiene una exposición por su ID
     * @param idExposicion
     * @return
     * @throws DAOException 
     */
    @Override
    public Exposicion obtener(Integer idExposicion) throws DAOException {
        //Exposicion a retornar
        Exposicion miExposicion = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando sus parámetros
            ps = conn.prepareStatement(GETONE);
            ps.setInt(1, idExposicion);
            
            //Ejecutamos la consulta y almacenamos en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miExposicion = new Exposicion();
                miExposicion.setIdExposicion(rs.getInt("idExposicion"));
                miExposicion.setIdGaleria(rs.getInt("idGaleria"));
                miExposicion.setTituloExposicion(rs.getString("tituloExposicion"));
                miExposicion.setFechaInicio(rs.getDate("fechaInicio"));
                miExposicion.setFechaFinal(rs.getDate("fechaFinal")); 
            }else {
                throw new DAOException ("No se encontro la exposición");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miExposicion;
    }//Fin del método obtener
    
    /**
     * Método que obtiene la exposición por su título
     * @param tituloExposicion
     * @return
     * @throws DAOException 
     */
    @Override
    public Exposicion obtenerPorTitulo(String tituloExposicion) throws DAOException {
        //Exposicion a retornar
        Exposicion miExposicion = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando sus parámetros
            ps = conn.prepareStatement(GETONEBYTITLE);
            ps.setString(1, tituloExposicion);
            
            //Ejecutamos la consulta y almacenamos en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miExposicion = new Exposicion();
                miExposicion.setIdExposicion(rs.getInt("idExposicion"));
                miExposicion.setIdGaleria(rs.getInt("idGaleria"));
                miExposicion.setTituloExposicion(rs.getString("tituloExposicion"));
                miExposicion.setFechaInicio(rs.getDate("fechaInicio"));
                miExposicion.setFechaFinal(rs.getDate("fechaFinal")); 
            }else {
                throw new DAOException ("No se encontro la exposición");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miExposicion;
    }//Fin del método obtenerPorTitulo
    
    /**
     * Método que obtiene las exposiciones que hay en una galería
     * @param idGaleria de la cual se quiere conocer las exposiciones
     * @return
     * @throws DAOException 
     */
    @Override
    public List<Exposicion> obtenerExposicionesPorGaleria(int idGaleria) throws DAOException {
        List<Exposicion> misExposiciones = null;
        try {
            //Creamos la instanciación del parámetro a retornar
            misExposiciones = new ArrayList<Exposicion>();
            
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta
            ps = conn.prepareStatement(GETALLEXPOSITIONSBYGALLERY);
            ps.setInt(1, idGaleria);
            
            //Ejecutamos la consulta y almacenamos el resultado en un objeto ResultSet
            rs = ps.executeQuery();
            
            //Recorremos el ResultSet y agregamos cada item al ArrayList
            while (rs.next()) {
                Exposicion miExposicion = new Exposicion();
                miExposicion.setIdExposicion(rs.getInt("idExposicion"));
                miExposicion.setIdGaleria(rs.getInt("idGaleria"));
                miExposicion.setTituloExposicion(rs.getString("tituloExposicion"));
                miExposicion.setFechaInicio(rs.getDate("fechaInicio"));
                miExposicion.setFechaFinal(rs.getDate("fechaFinal")); 
                misExposiciones.add(miExposicion);
            }
        }catch(SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
        
        return misExposiciones;
    }
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
    
    /**
     * Método para convertir java.util.Date a java.sql.Date
     * @param utilfecha
     * @return 
     */
    private java.sql.Date convertir(java.util.Date utilfecha) {
        java.sql.Date sqlDate = new java.sql.Date(utilfecha.getTime());
        return sqlDate;
    }
    
}//Fin de la clase MySQLExposicionDAO
