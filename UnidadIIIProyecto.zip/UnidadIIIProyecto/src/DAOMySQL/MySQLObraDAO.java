/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IObraDAO;
import Modelo.Obra;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLObraDAO implements IObraDAO {
    
    //Propiedades para controlar la base de datos
    private Connection conn = null;
    private ResultSet rs = null;
    private PreparedStatement ps = null;
    
    //Consultas SQL
    private final String INSERT = "INSERT INTO obra (idAutor, tituloObra,"
            + " corrienteArtistica, tecnica, anio) VALUES (?, ?, ?, ?, ?)";
    
    private final String UPDATE = "UPDATE obra SET idAutor = ?, tituloObra = ?,"
            + " corrienteArtistica = ?, tecnica = ?, anio = ? WHERE idObra = ?";
    
    private final String DELETE = "DELETE FROM obra WHERE idObra = ?";
    
    private final String GETONE = "SELECT idObra, idAutor, tituloObra,"
            + " corrienteArtistica, tecnica, anio FROM obra WHERE idObra = ?";
    
    private final String GETALLARTWORKSBYAUTHOR = "SELECT idObra, idAutor, tituloObra,"
            + " corrienteArtistica, tecnica, anio FROM obra WHERE idAutor = ?";
    
    /**
     * Método para insertar una obra
     * @param obra
     * @throws DAOException 
     */
    @Override
    public void insertar(Obra obra) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros
            ps = conn.prepareStatement(INSERT,
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, obra.getIdAutor());
            ps.setString(2, obra.getTituloObra());
            ps.setString(3, obra.getCorrienteArtistica());
            ps.setString(4, obra.getTecnica());
            ps.setString(5, obra.getAnio());
            
            //Ejecutamos la cosulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("No se pudo guardar el nuevo autor");
            }else {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    obra.setIdObra(rs.getInt(1));
                }else {
                    throw new DAOException("No se pudo "
                            + "asignar el ID a esta obra");
                }
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método insertar
    
    /**
     * Método para modificar una obra
     * @param obra
     * @throws DAOException 
     */
    @Override
    public void modificar(Obra obra) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros de entrada
            ps = conn.prepareStatement(UPDATE);
            ps.setInt(1, obra.getIdAutor());
            ps.setString(2, obra.getTituloObra());
            ps.setString(3, obra.getCorrienteArtistica());
            ps.setString(4, obra.getTecnica());
            ps.setString(5, obra.getAnio());
            ps.setInt(6, obra.getIdObra());
            
            //Ejecutamos la consulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se guardaron los"
                        + " cambios");
            }
        }catch (SQLException ex) {
            throw new DAOException("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método modificar
    
    /**
     * Método para eliminar una obra
     * @param idObra
     * @throws DAOException 
     */
    @Override
    public void eliminar(Integer idObra) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando parametros de entrada
            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, idObra);
            
            //Ejecutamos la consulta y verificamos el resultado 
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se pudo eliminar"
                        + " el registro");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método eliminar
    
    /**
     * Método para obtener una obra
     * @param idObra
     * @return
     * @throws DAOException 
     */
    @Override
    public Obra obtener(Integer idObra) throws DAOException {
        //Autor a retornar
        Obra miObra = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando sus parámetros
            ps = conn.prepareStatement(GETONE);
            ps.setInt(1, idObra);
            
            //Ejecutamos la consulta y almacenamos en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miObra = new Obra();
                miObra.setIdObra(rs.getInt("idObra"));
                miObra.setIdAutor(rs.getInt("idAutor"));
                miObra.setTituloObra(rs.getString("tituloObra"));
                miObra.setCorrienteArtistica(rs.getString("corrienteArtistica"));
                miObra.setTecnica(rs.getString("tecnica"));
                miObra.setAnio(rs.getString("anio"));
            }else {
                throw new DAOException ("No se encontro la obra");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miObra;
    }//Fin del método obtener
    
    /**
     * Método que obtiene las obras de un autor
     * @param idAutor el cual se quiere obtener sus obras
     * @return
     * @throws DAOException 
     */
    @Override
    public List<Obra> obtenerObrasPorAutor(int idAutor) throws DAOException {
        List<Obra> misObras = null;
        try {
            //Creamos la instanciación del parámetro a retornar
            misObras = new ArrayList<Obra>();
            
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta
            ps = conn.prepareStatement(GETALLARTWORKSBYAUTHOR);
            ps.setInt(1, idAutor);
            
            //Ejecutamos la consulta y almacenamos el resultado en un objeto ResultSet
            rs = ps.executeQuery();
            
            //Recorremos el ResultSet y agregamos cada item al ArrayList
            while (rs.next()) {
                Obra miObra = new Obra();
                miObra.setIdObra(rs.getInt("idObra"));
                miObra.setIdAutor(rs.getInt("idAutor"));
                miObra.setTituloObra(rs.getString("tituloObra"));
                miObra.setCorrienteArtistica(rs.getString("corrienteArtistica"));
                miObra.setTecnica(rs.getString("tecnica"));
                miObra.setAnio(rs.getString("anio"));
                misObras.add(miObra);
            }
        }catch(SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
        
        return misObras;
    }
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
    
}//Fin de la clase MySQLObraDAO
