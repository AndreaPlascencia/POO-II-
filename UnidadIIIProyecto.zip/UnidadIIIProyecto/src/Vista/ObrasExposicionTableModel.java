/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import DAO.DAOException;
import DAO.IExhibicionDAO;
import Modelo.Obra;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Andrea Plascencia
 */
public class ObrasExposicionTableModel extends AbstractTableModel {
    
    //Propiedades
    private IExhibicionDAO exhibicion;
    
    //Lista de elementos de tipo Obra
    private List<Obra> datosExhibicion = new ArrayList<>();
    
    //Constructor
    public ObrasExposicionTableModel (IExhibicionDAO exhibicion) {
        this.exhibicion = exhibicion;
    }
    
    /**
     * Retorna el nombre de cada columna
     * @param column
     * @return 
     */
    @Override
    public String getColumnName (int column) {
        switch(column) {
            case 0: return "ID Obra";
            case 1: return "ID Autor";
            case 2: return "Título de la Obra";
            case 3: return "Corriente Artística";
            case 4: return "Técnica";
            case 5: return "Año";
            default: return "[no]";
        }
    }
    
    /**
     * Retorna el número de elementos obtenidos de la tabla obra
     * @return 
     */
    @Override
    public int getRowCount() {
        return datosExhibicion.size();
    }
    
    /**
     * Número de columnas
     * @return 
     */
    @Override
    public int getColumnCount() {
        return 6;
    }
    
    /**
     * Retorna el valor de alguna intersección
     * @param rowIndex
     * @param columnIndex
     * @return 
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Obra preguntada = datosExhibicion.get(rowIndex);
        switch (columnIndex) {
            case 0: return preguntada.getIdObra();
            case 1: return preguntada.getIdAutor();
            case 2: return preguntada.getTituloObra();
            case 3: return preguntada.getCorrienteArtistica();
            case 4: return preguntada.getTecnica();
            case 5: return preguntada.getAnio();
            default: return "";
        }
    }
    
    /**
     * Muestra una lista de las obras que estarán en una exposición
     * @param idExposicion
     * @throws DAOException 
     */
    public void updateModel(int idExposicion) throws DAOException {
        this.datosExhibicion = exhibicion.obtenerObrasPorExposicion(idExposicion);
    }
    
}//Fin de la clase ObrasExposicionTableModel
