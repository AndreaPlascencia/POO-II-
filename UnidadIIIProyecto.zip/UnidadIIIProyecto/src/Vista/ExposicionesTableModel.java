/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import DAO.DAOException;
import DAO.IExposicionDAO;
import Modelo.Exposicion;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Andrea Plascencia
 */
public class ExposicionesTableModel extends AbstractTableModel {
    
    //Propiedades
    private IExposicionDAO exposicion;;
    
    //Lista de elementos de tipo Exposicion
    private List<Exposicion> datos = new ArrayList<>();
    
    //Se da formato a la variable de tipo Date 
    SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
    
    //Constructor
    public ExposicionesTableModel (IExposicionDAO exposicion) {
        this.exposicion = exposicion;
    }
    
    
    /**
     * Retorna el nombre de cada columna de la tabla exposicion
     * @param column
     * @return 
     */
    @Override
    public String getColumnName (int column) {
        switch(column) {
            case 0: return "ID Exposición";
            case 1: return "ID Galería";
            case 2: return "Título de la Exposición";
            case 3: return "Fecha de Inicio";
            case 4: return "Fecha de Fin";
            default: return "[no]";
        }
    }
    
    /**
     * Retorna el número de elementos obtenidos de la tabla exposicion
     * @return 
     */
    @Override
    public int getRowCount() {
        return datos.size();
    }
    
    /**
     * Retorna el número de columnas
     * @return 
     */
    @Override
    public int getColumnCount() {
        return 5;
    }

    /**
     * Retorna el valor de alguna intersección
     * @param rowIndex
     * @param columnIndex
     * @return 
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Exposicion preguntado = datos.get(rowIndex);
        switch (columnIndex) {
            case 0: return preguntado.getIdExposicion();
            case 1: return preguntado.getIdGaleria();
            case 2: return preguntado.getTituloExposicion();
            case 3: return formato.format(preguntado.getFechaInicio());
            case 4: return formato.format(preguntado.getFechaFinal());
            default: return "";
        }
    }
    
    /**
     * Muestra una lista de la tabla exposicion basandose en su galeria
     * @param idGaleria
     * @throws DAOException 
     */
    public void updateModel(int idGaleria) throws DAOException {
        this.datos = exposicion.obtenerExposicionesPorGaleria(idGaleria);
    }
    
}//Fin de la clase ExposicionesTableModel
