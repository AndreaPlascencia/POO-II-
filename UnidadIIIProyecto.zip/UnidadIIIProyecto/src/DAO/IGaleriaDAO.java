/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Galeria;

/**
 *
 * @author Andrea Plascencia
 */
public interface IGaleriaDAO extends IDAO <Galeria, Integer> {
    
}
