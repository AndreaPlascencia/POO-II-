/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Exhibicion;
import Modelo.Exposicion;
import Modelo.Obra;
import java.util.List;
import net.sf.jasperreports.engine.JasperPrint;

/**
 *
 * @author Andrea Plascencia
 */
public interface IExhibicionDAO extends IDAO <Exhibicion, Integer>  {
    
    List<Obra> obtenerObrasPorExposicion(int idExposicion) throws DAOException;
    
    List<Exposicion> obtenerExposicionesDeLaObra(int idObra) throws DAOException;
    
    void eliminar(Exhibicion a) throws DAOException;
    
    JasperPrint crearReporte (String ruta, int miParametro) throws DAOException;
    
}//Fin de la interface IExhibicionDAO
